package com.reservemicroservice.reservemicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReserveMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
