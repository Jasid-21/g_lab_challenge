package com.admin_authmicroservice.admin_authmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminAuthMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
