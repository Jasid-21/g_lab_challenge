package com.admin_authmicroservice.admin_authmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminAuthMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminAuthMicroserviceApplication.class, args);
	}

}
